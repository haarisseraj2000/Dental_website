This web page is made using html css bootstrap js php and the localhost server used is Mamp crediantials goes to mr web developer 

for any issues mail me on hritikranjan1804@gmail.com